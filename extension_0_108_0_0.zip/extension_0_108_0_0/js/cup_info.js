var cup_info = {
	beginner: {
		name: "Ice Dodo",
		song: "env2.mp3"
	},
	carrot: {
		name: "Carrot cup",
		song: "tokyo.mp3"
	},
	rocky: {
		name: "Rocky cup",
		song: "stairways.mp3"
	},
	dodo: {
		name: "Dodo cup",
		song: "env2.mp3"
	},
	skilled: {
		name: "Skilled cup",
		song: "env2.mp3"
	},
	furby: {
		name: "Furby cup",
		song: "tokyo.mp3"
	},
	doom: {
		name: "Doom cup",
		song: "env2.mp3"
	},
	kazil: {
		name: "Kazil cup",
		song: "stairways.mp3"
	},
	ye: {
		name: "Ye cup",
		song: "tokyo.mp3"
	},
	tim: {
		name: "Tim cup",
		song: "tokyo.mp3"
	},
	ghoul: {
		name: "Ghoul cup",
		song: "env2.mp3"
	},
	rytai: {
		name: "Rytai cup",
		song: "tokyo.mp3"
	},
	jay: {
		name: "Jay cup",
		song: "stairways.mp3"
	},
	crazy: {
		name: "Crazy cup",
		song: "tokyo.mp3"
	},
	june: {
		name: "June cup",
		song: "stairways.mp3"
	},
	sleepy: {
		name: "Sleepy cup",
		song: "env2.mp3"
	},
	mango: {
		name: "Mango cup",
		song: "tokyo.mp3"
	},
	squirrel: {
		name: "Squirrel cup",
		song: "stairways.mp3"
	},
	collab: {
		name: "Collab cup",
		song: "env2.mp3"
	},
	og: {
		name: "O.G. cup",
		song: "env2.mp3"
	},
	vault: {
		name: "Vault cup",
		song: "env2.mp3"
	},
	finder: {
		name: "Finder",
		song: "env2.mp3"
	}
}